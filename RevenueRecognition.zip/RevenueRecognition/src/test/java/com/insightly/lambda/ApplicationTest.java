package com.insightly.lambda;

import com.amazonaws.services.lambda.runtime.Context;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import static org.mockito.Mockito.mock;

public class ApplicationTest {


    @Test
    public void test() throws Exception {
        CreateFinancials handler = new CreateFinancials();

        File file = new File("src/test/resources/opportunity.json");
        InputStream lambdaRequest = new FileInputStream(file);
        ByteArrayOutputStream lambdaResponse = new ByteArrayOutputStream();
        Context context = mock(Context.class);

        System.setProperty("insightly_apiKey","37055d71-8bcc-4325-8357-d4c584a9cc3d");
        handler.handleRequest(lambdaRequest, lambdaResponse, context);
    }

}