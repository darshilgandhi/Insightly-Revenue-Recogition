package com.insightly.lambda.pojo.task;

import com.fasterxml.jackson.annotation.*;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "LINK_ID",
        "OBJECT_NAME",
        "OBJECT_ID",
        "LINK_OBJECT_NAME",
        "LINK_OBJECT_ID"
})
public class Task_Link {

    @JsonProperty("LINK_ID")
    private Long lINKID;
    @JsonProperty("OBJECT_NAME")
    private String oBJECTNAME;
    @JsonProperty("OBJECT_ID")
    private Long oBJECTID;
    @JsonProperty("LINK_OBJECT_NAME")
    private String lINKOBJECTNAME;
    @JsonProperty("LINK_OBJECT_ID")
    private Long lINKOBJECTID;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("LINK_ID")
    public Long getLINKID() {
        return lINKID;
    }

    @JsonProperty("LINK_ID")
    public void setLINKID(Long lINKID) {
        this.lINKID = lINKID;
    }

    @JsonProperty("OBJECT_NAME")
    public String getOBJECTNAME() {
        return oBJECTNAME;
    }

    @JsonProperty("OBJECT_NAME")
    public void setOBJECTNAME(String oBJECTNAME) {
        this.oBJECTNAME = oBJECTNAME;
    }

    @JsonProperty("OBJECT_ID")
    public Long getOBJECTID() {
        return oBJECTID;
    }

    @JsonProperty("OBJECT_ID")
    public void setOBJECTID(Long oBJECTID) {
        this.oBJECTID = oBJECTID;
    }

    @JsonProperty("LINK_OBJECT_NAME")
    public String getLINKOBJECTNAME() {
        return lINKOBJECTNAME;
    }

    @JsonProperty("LINK_OBJECT_NAME")
    public void setLINKOBJECTNAME(String lINKOBJECTNAME) {
        this.lINKOBJECTNAME = lINKOBJECTNAME;
    }

    @JsonProperty("LINK_OBJECT_ID")
    public Long getLINKOBJECTID() {
        return lINKOBJECTID;
    }

    @JsonProperty("LINK_OBJECT_ID")
    public void setLINKOBJECTID(Long lINKOBJECTID) {
        this.lINKOBJECTID = lINKOBJECTID;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}