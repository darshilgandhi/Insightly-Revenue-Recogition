package com.insightly.lambda.pojo.task;

import com.fasterxml.jackson.annotation.*;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "TASK_ID",
        "TITLE",
        "CATEGORY_ID",
        "DUE_DATE",
        "COMPLETED_DATE_UTC",
        "COMPLETED",
        "DETAILS",
        "STATUS",
        "PRIORITY",
        "PERCENT_COMPLETE",
        "START_DATE",
        "MILESTONE_ID",
        "RESPONSIBLE_USER_ID",
        "OWNER_USER_ID",
        "DATE_CREATED_UTC",
        "DATE_UPDATED_UTC",
        "EMAIL_ID",
        "PROJECT_ID",
        "REMINDER_DATE_UTC",
        "REMINDER_SENT",
        "OWNER_VISIBLE",
        "STAGE_ID",
        "ASSIGNED_BY_USER_ID",
        "PARENT_TASK_ID",
        "RECURRENCE",
        "OPPORTUNITY_ID",
        "ASSIGNED_TEAM_ID",
        "ASSIGNED_DATE_UTC",
        "CREATED_USER_ID"
})
public class Task {

    @JsonProperty("TASK_ID")
    private Long tASKID;
    @JsonProperty("TITLE")
    private String tITLE;
    @JsonProperty("CATEGORY_ID")
    private Long cATEGORYID;
    @JsonProperty("DUE_DATE")
    private String dUEDATE;
    @JsonProperty("COMPLETED_DATE_UTC")
    private Object cOMPLETEDDATEUTC;
    @JsonProperty("COMPLETED")
    private Boolean cOMPLETED;
    @JsonProperty("DETAILS")
    private String dETAILS;
    @JsonProperty("STATUS")
    private String sTATUS;
    @JsonProperty("PRIORITY")
    private Long pRIORITY;
    @JsonProperty("PERCENT_COMPLETE")
    private Long pERCENTCOMPLETE;
    @JsonProperty("START_DATE")
    private Object sTARTDATE;
    @JsonProperty("MILESTONE_ID")
    private Object mILESTONEID;
    @JsonProperty("RESPONSIBLE_USER_ID")
    private Long rESPONSIBLEUSERID;
    @JsonProperty("OWNER_USER_ID")
    private Long oWNERUSERID;
    @JsonProperty("DATE_CREATED_UTC")
    private String dATECREATEDUTC;
    @JsonProperty("DATE_UPDATED_UTC")
    private String dATEUPDATEDUTC;
    @JsonProperty("EMAIL_ID")
    private Object eMAILID;
    @JsonProperty("PROJECT_ID")
    private Long pROJECTID;
    @JsonProperty("REMINDER_DATE_UTC")
    private Object rEMINDERDATEUTC;
    @JsonProperty("REMINDER_SENT")
    private Boolean rEMINDERSENT;
    @JsonProperty("OWNER_VISIBLE")
    private Boolean oWNERVISIBLE;
    @JsonProperty("STAGE_ID")
    private Long sTAGEID;
    @JsonProperty("ASSIGNED_BY_USER_ID")
    private Object aSSIGNEDBYUSERID;
    @JsonProperty("PARENT_TASK_ID")
    private Object pARENTTASKID;
    @JsonProperty("RECURRENCE")
    private Object rECURRENCE;
    @JsonProperty("OPPORTUNITY_ID")
    private Object oPPORTUNITYID;
    @JsonProperty("ASSIGNED_TEAM_ID")
    private Object aSSIGNEDTEAMID;
    @JsonProperty("ASSIGNED_DATE_UTC")
    private Object aSSIGNEDDATEUTC;
    @JsonProperty("CREATED_USER_ID")
    private Long cREATEDUSERID;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("TASK_ID")
    public Long getTASKID() {
        return tASKID;
    }

    @JsonProperty("TASK_ID")
    public void setTASKID(Long tASKID) {
        this.tASKID = tASKID;
    }

    @JsonProperty("TITLE")
    public String getTITLE() {
        return tITLE;
    }

    @JsonProperty("TITLE")
    public void setTITLE(String tITLE) {
        this.tITLE = tITLE;
    }

    @JsonProperty("CATEGORY_ID")
    public Long getCATEGORYID() {
        return cATEGORYID;
    }

    @JsonProperty("CATEGORY_ID")
    public void setCATEGORYID(Long cATEGORYID) {
        this.cATEGORYID = cATEGORYID;
    }

    @JsonProperty("DUE_DATE")
    public String getDUEDATE() {
        return dUEDATE;
    }

    @JsonProperty("DUE_DATE")
    public void setDUEDATE(String dUEDATE) {
        this.dUEDATE = dUEDATE;
    }

    @JsonProperty("COMPLETED_DATE_UTC")
    public Object getCOMPLETEDDATEUTC() {
        return cOMPLETEDDATEUTC;
    }

    @JsonProperty("COMPLETED_DATE_UTC")
    public void setCOMPLETEDDATEUTC(Object cOMPLETEDDATEUTC) {
        this.cOMPLETEDDATEUTC = cOMPLETEDDATEUTC;
    }

    @JsonProperty("COMPLETED")
    public Boolean getCOMPLETED() {
        return cOMPLETED;
    }

    @JsonProperty("COMPLETED")
    public void setCOMPLETED(Boolean cOMPLETED) {
        this.cOMPLETED = cOMPLETED;
    }

    @JsonProperty("DETAILS")
    public String getDETAILS() {
        return dETAILS;
    }

    @JsonProperty("DETAILS")
    public void setDETAILS(String dETAILS) {
        this.dETAILS = dETAILS;
    }

    @JsonProperty("STATUS")
    public String getSTATUS() {
        return sTATUS;
    }

    @JsonProperty("STATUS")
    public void setSTATUS(String sTATUS) {
        this.sTATUS = sTATUS;
    }

    @JsonProperty("PRIORITY")
    public Long getPRIORITY() {
        return pRIORITY;
    }

    @JsonProperty("PRIORITY")
    public void setPRIORITY(Long pRIORITY) {
        this.pRIORITY = pRIORITY;
    }

    @JsonProperty("PERCENT_COMPLETE")
    public Long getPERCENTCOMPLETE() {
        return pERCENTCOMPLETE;
    }

    @JsonProperty("PERCENT_COMPLETE")
    public void setPERCENTCOMPLETE(Long pERCENTCOMPLETE) {
        this.pERCENTCOMPLETE = pERCENTCOMPLETE;
    }

    @JsonProperty("START_DATE")
    public Object getSTARTDATE() {
        return sTARTDATE;
    }

    @JsonProperty("START_DATE")
    public void setSTARTDATE(Object sTARTDATE) {
        this.sTARTDATE = sTARTDATE;
    }

    @JsonProperty("MILESTONE_ID")
    public Object getMILESTONEID() {
        return mILESTONEID;
    }

    @JsonProperty("MILESTONE_ID")
    public void setMILESTONEID(Object mILESTONEID) {
        this.mILESTONEID = mILESTONEID;
    }

    @JsonProperty("RESPONSIBLE_USER_ID")
    public Long getRESPONSIBLEUSERID() {
        return rESPONSIBLEUSERID;
    }

    @JsonProperty("RESPONSIBLE_USER_ID")
    public void setRESPONSIBLEUSERID(Long rESPONSIBLEUSERID) {
        this.rESPONSIBLEUSERID = rESPONSIBLEUSERID;
    }

    @JsonProperty("OWNER_USER_ID")
    public Long getOWNERUSERID() {
        return oWNERUSERID;
    }

    @JsonProperty("OWNER_USER_ID")
    public void setOWNERUSERID(Long oWNERUSERID) {
        this.oWNERUSERID = oWNERUSERID;
    }

    @JsonProperty("DATE_CREATED_UTC")
    public String getDATECREATEDUTC() {
        return dATECREATEDUTC;
    }

    @JsonProperty("DATE_CREATED_UTC")
    public void setDATECREATEDUTC(String dATECREATEDUTC) {
        this.dATECREATEDUTC = dATECREATEDUTC;
    }

    @JsonProperty("DATE_UPDATED_UTC")
    public String getDATEUPDATEDUTC() {
        return dATEUPDATEDUTC;
    }

    @JsonProperty("DATE_UPDATED_UTC")
    public void setDATEUPDATEDUTC(String dATEUPDATEDUTC) {
        this.dATEUPDATEDUTC = dATEUPDATEDUTC;
    }

    @JsonProperty("EMAIL_ID")
    public Object getEMAILID() {
        return eMAILID;
    }

    @JsonProperty("EMAIL_ID")
    public void setEMAILID(Object eMAILID) {
        this.eMAILID = eMAILID;
    }

    @JsonProperty("PROJECT_ID")
    public Long getPROJECTID() {
        return pROJECTID;
    }

    @JsonProperty("PROJECT_ID")
    public void setPROJECTID(Long pROJECTID) {
        this.pROJECTID = pROJECTID;
    }

    @JsonProperty("REMINDER_DATE_UTC")
    public Object getREMINDERDATEUTC() {
        return rEMINDERDATEUTC;
    }

    @JsonProperty("REMINDER_DATE_UTC")
    public void setREMINDERDATEUTC(Object rEMINDERDATEUTC) {
        this.rEMINDERDATEUTC = rEMINDERDATEUTC;
    }

    @JsonProperty("REMINDER_SENT")
    public Boolean getREMINDERSENT() {
        return rEMINDERSENT;
    }

    @JsonProperty("REMINDER_SENT")
    public void setREMINDERSENT(Boolean rEMINDERSENT) {
        this.rEMINDERSENT = rEMINDERSENT;
    }

    @JsonProperty("OWNER_VISIBLE")
    public Boolean getOWNERVISIBLE() {
        return oWNERVISIBLE;
    }

    @JsonProperty("OWNER_VISIBLE")
    public void setOWNERVISIBLE(Boolean oWNERVISIBLE) {
        this.oWNERVISIBLE = oWNERVISIBLE;
    }

    @JsonProperty("STAGE_ID")
    public Long getSTAGEID() {
        return sTAGEID;
    }

    @JsonProperty("STAGE_ID")
    public void setSTAGEID(Long sTAGEID) {
        this.sTAGEID = sTAGEID;
    }

    @JsonProperty("ASSIGNED_BY_USER_ID")
    public Object getASSIGNEDBYUSERID() {
        return aSSIGNEDBYUSERID;
    }

    @JsonProperty("ASSIGNED_BY_USER_ID")
    public void setASSIGNEDBYUSERID(Object aSSIGNEDBYUSERID) {
        this.aSSIGNEDBYUSERID = aSSIGNEDBYUSERID;
    }

    @JsonProperty("PARENT_TASK_ID")
    public Object getPARENTTASKID() {
        return pARENTTASKID;
    }

    @JsonProperty("PARENT_TASK_ID")
    public void setPARENTTASKID(Object pARENTTASKID) {
        this.pARENTTASKID = pARENTTASKID;
    }

    @JsonProperty("RECURRENCE")
    public Object getRECURRENCE() {
        return rECURRENCE;
    }

    @JsonProperty("RECURRENCE")
    public void setRECURRENCE(Object rECURRENCE) {
        this.rECURRENCE = rECURRENCE;
    }

    @JsonProperty("OPPORTUNITY_ID")
    public Object getOPPORTUNITYID() {
        return oPPORTUNITYID;
    }

    @JsonProperty("OPPORTUNITY_ID")
    public void setOPPORTUNITYID(Object oPPORTUNITYID) {
        this.oPPORTUNITYID = oPPORTUNITYID;
    }

    @JsonProperty("ASSIGNED_TEAM_ID")
    public Object getASSIGNEDTEAMID() {
        return aSSIGNEDTEAMID;
    }

    @JsonProperty("ASSIGNED_TEAM_ID")
    public void setASSIGNEDTEAMID(Object aSSIGNEDTEAMID) {
        this.aSSIGNEDTEAMID = aSSIGNEDTEAMID;
    }

    @JsonProperty("ASSIGNED_DATE_UTC")
    public Object getASSIGNEDDATEUTC() {
        return aSSIGNEDDATEUTC;
    }

    @JsonProperty("ASSIGNED_DATE_UTC")
    public void setASSIGNEDDATEUTC(Object aSSIGNEDDATEUTC) {
        this.aSSIGNEDDATEUTC = aSSIGNEDDATEUTC;
    }

    @JsonProperty("CREATED_USER_ID")
    public Long getCREATEDUSERID() {
        return cREATEDUSERID;
    }

    @JsonProperty("CREATED_USER_ID")
    public void setCREATEDUSERID(Long cREATEDUSERID) {
        this.cREATEDUSERID = cREATEDUSERID;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}