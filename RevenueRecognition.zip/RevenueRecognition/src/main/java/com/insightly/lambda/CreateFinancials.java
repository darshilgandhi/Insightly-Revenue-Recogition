package com.insightly.lambda;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestStreamHandler;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.insightly.lambda.pojo.customObject.CustomObject;
import com.insightly.lambda.pojo.customObject.CustomObject_CustomField;
import com.insightly.lambda.pojo.opportunities.Opportunity;
import com.insightly.lambda.services.RESTCalls;
import com.insightly.lambda.utils.Properties;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

//You can also implement Requesthandler instead of RequestStreamhandler if you want AWS Lambda to serialize data.
//More information can be found here -> http://docs.aws.amazon.com/lambda/latest/dg/java-programming-model-handler-types.html
//You can use Log4J or AWS Logger. More information can be found here -> http://docs.aws.amazon.com/lambda/latest/dg/java-logging.html
public class CreateFinancials implements RequestStreamHandler {

    //Using log4j
    private static final Logger logger = LogManager.getLogger(CreateFinancials.class);
    private Properties properties = Properties.getInstance();
    private RESTCalls apiCalls = new RESTCalls();


    public void handleRequest(InputStream inputStream, OutputStream outputStream, Context context) {

        //Read env variables set in AWS Lambda for use in the app
        properties.setApiKey(System.getenv("insightly_apiKey"));

        //Set MRR to true if MrrEnabled
        if (System.getenv("mrrEnabled").equalsIgnoreCase("true")) {
            properties.setMrrEnabled(true);
        }

        try {
            //Converting inputStream into String
            JsonNode entity = properties.getMapper().readValue(inputStream, JsonNode.class);
            if (entity.has("insightly")) {

                long recordId = entity.get("insightly").get("recordId").asLong();
                String recordType = entity.get("insightly").get("recordType").asText();
                Opportunity opportunity = null;
                if (recordType.equalsIgnoreCase("Opportunity")) {
                    opportunity = properties.getMapper().readValue(entity.get("insightly").get("newValue").toString(), Opportunity.class);
                }

                if (opportunity != null) {
                    //Method creates RR entries
                    createFinancials(recordId, recordType, opportunity);
                }
            } else {
                logger.error("Invalid object");
            }
        } catch (IOException e) {
            logger.error(Arrays.toString(e.getStackTrace()));
        }

    }

    //Implementation
    private void createFinancials(Long recordId, String recordType, Opportunity opportunity) throws JsonProcessingException {
        logger.info("Record ID: " + recordId);
        try {
            logger.debug("Opportunity: " + properties.getMapper().writeValueAsString(opportunity));
        } catch (JsonProcessingException e) {
            logger.error("Error while printing Opportunity.");
        }

        logger.info("Opportunity - Value: $" + opportunity.getOPPORTUNITYVALUE() + ". Amount: $" + opportunity.getBIDAMOUNT() + ". Duration/Length: " +opportunity.getBIDDURATION() + ". Bid Type: " + opportunity.getBIDTYPE());

        int duration, totalMonths = 0;

        if (opportunity.getBIDDURATION() != null) {
            duration = Math.toIntExact(opportunity.getBIDDURATION());
        } else {
            duration = 1;
        }

        double monthlyValue = 0.0;
        if (opportunity.getBIDTYPE().equalsIgnoreCase("Per Year")) {
            totalMonths = duration * 12;
            monthlyValue = opportunity.getBIDAMOUNT() / 12;
        } else if (opportunity.getBIDTYPE().equalsIgnoreCase("Per Month")) {
            totalMonths = duration;
            monthlyValue = opportunity.getBIDAMOUNT();
        } else if (opportunity.getBIDTYPE().equalsIgnoreCase("Per week")) {
            int quotient = duration / 4;
            int remainder = duration % 4;
            logger.debug("Quotient: " + quotient + ". Remainder: " + remainder);
            if (remainder != 0) {
                totalMonths = quotient + 1;
            } else {
                totalMonths = quotient;
            }
            monthlyValue = opportunity.getBIDAMOUNT() * 4;
        } else if (opportunity.getBIDTYPE().equalsIgnoreCase("Per Day")) {
            int quotient = duration / 30;
            int remainder = duration % 30;
            logger.debug("Quotient: " + quotient + ". Remainder: " + remainder);
            if (remainder != 0) {
                totalMonths = quotient + 1;
            } else {
                totalMonths = quotient;
            }
            monthlyValue = opportunity.getBIDAMOUNT() * 30;
        } else if (opportunity.getBIDTYPE().equalsIgnoreCase("Fixed Bid")) {
            totalMonths = 1;
            monthlyValue = opportunity.getOPPORTUNITYVALUE();
        } else {
            logger.error("Bid Type " + opportunity.getBIDTYPE() + " does not match any pre-defined data points.");
        }

        logger.info("Total Months: " + totalMonths);

        String actualCloseDate = opportunity.getACTUALCLOSEDATE();
        logger.info("Actual Close Date: " + actualCloseDate);


        LocalDateTime localDateTime = null;
        if (actualCloseDate != null) {
            try {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                localDateTime = LocalDateTime.parse(actualCloseDate, formatter);
            } catch (Exception e) {
                try {
                    localDateTime = LocalDateTime.parse(actualCloseDate, DateTimeFormatter.ISO_DATE_TIME);
                } catch (Exception ex) {
                    logger.error("Error while parsing dates. " + ex.getMessage());
                }

            }

            if (localDateTime != null) {
                int year = localDateTime.getYear();
                Month month = localDateTime.getMonth();
                String monthDisplayName = month.getDisplayName(TextStyle.FULL, Locale.US);
                int monthValue = month.getValue();


                while (totalMonths > 0) {

                    createRecords(year, monthValue, monthDisplayName, totalMonths, monthlyValue, duration, opportunity);
                    monthValue++;
                    if (monthValue == 13) {
                        monthValue = 1;
                        year++;
                    }

                    totalMonths--;
                }
            }
        }
    }

    private void createRecords(int year, int monthValue, String monthDisplayName, int totalMonths, double monthlyValue, int duration, Opportunity opportunity) throws JsonProcessingException {

        BigDecimal bd = new BigDecimal(monthlyValue);
        bd = bd.setScale(2, RoundingMode.HALF_UP);

        if (monthValue == 1) {
            monthDisplayName = "January";
        } else if (monthValue == 2) {
            monthDisplayName = "February";
        } else if (monthValue == 3) {
            monthDisplayName = "March";
        } else if (monthValue == 4) {
            monthDisplayName = "April";
        } else if (monthValue == 5) {
            monthDisplayName = "May";
        } else if (monthValue == 6) {
            monthDisplayName = "June";
        } else if (monthValue == 7) {
            monthDisplayName = "July";
        } else if (monthValue == 8) {
            monthDisplayName = "August";
        } else if (monthValue == 9) {
            monthDisplayName = "September";
        } else if (monthValue == 10) {
            monthDisplayName = "October";
        } else if (monthValue == 11) {
            monthDisplayName = "November";
        } else if (monthValue == 12) {
            monthDisplayName = "December";
        }

        String recordName = opportunity.getOPPORTUNITYNAME() + " - " + year + " | " + monthDisplayName;

        CustomObject object = new CustomObject();
        object.setRECORDNAME(recordName);

        List<CustomObject_CustomField> customObjectCustomFieldList = new ArrayList<CustomObject_CustomField>();

        CustomObject_CustomField customField = new CustomObject_CustomField();
        customField.setFIELDNAME("Month__c");
        customField.setFIELDVALUE(monthDisplayName);
        customObjectCustomFieldList.add(customField);

        customField = new CustomObject_CustomField();
        customField.setFIELDNAME("Year__c");
        customField.setFIELDVALUE(year);
        customObjectCustomFieldList.add(customField);

        customField = new CustomObject_CustomField();
        customField.setFIELDNAME("Payment_Status__c");
        customField.setFIELDVALUE("Open");
        customObjectCustomFieldList.add(customField);

        LocalDate localDate = LocalDate.of(year, monthValue, 15);
        Instant instant = localDate.atStartOfDay(ZoneId.of("America/Los_Angeles")).toInstant();
        customField = new CustomObject_CustomField();
        customField.setFIELDNAME("Revenue_Recognition_Date__c");
        customField.setFIELDVALUE(instant.toString());
        customObjectCustomFieldList.add(customField);

        customField = new CustomObject_CustomField();
        customField.setFIELDNAME("Opportunity__c");
        customField.setFIELDVALUE(opportunity.getOPPORTUNITYID());
        customObjectCustomFieldList.add(customField);

        customField = new CustomObject_CustomField();
        customField.setFIELDNAME("Organization__c");
        customField.setFIELDVALUE(opportunity.getORGANISATIONID());
        customObjectCustomFieldList.add(customField);

        customField = new CustomObject_CustomField();
        customField.setFIELDNAME("Value__c");
        customField.setFIELDVALUE(bd.doubleValue());
        customObjectCustomFieldList.add(customField);

        object.setCUSTOMFIELDS(customObjectCustomFieldList);

        logger.debug(apiCalls.updateMethod("revenue_recognition__c", "POST", properties.getMapper().writeValueAsString(object)));
    }
}