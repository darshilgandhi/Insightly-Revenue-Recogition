package com.insightly.lambda.pojo.contact;

import com.fasterxml.jackson.annotation.*;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "insightly"
})
public class Insightly_Object_Contact {

    @JsonProperty("insightly")
    private Insightly_Object_Contact_Details insightly;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("insightly")
    public Insightly_Object_Contact_Details getInsightly() {
        return insightly;
    }

    @JsonProperty("insightly")
    public void setInsightly(Insightly_Object_Contact_Details insightly) {
        this.insightly = insightly;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
