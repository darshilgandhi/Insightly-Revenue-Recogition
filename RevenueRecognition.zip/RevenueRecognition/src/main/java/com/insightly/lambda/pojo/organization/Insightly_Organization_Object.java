package com.insightly.lambda.pojo.organization;

import com.fasterxml.jackson.annotation.*;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "insightly"
})
public class Insightly_Organization_Object {

    @JsonProperty("insightly")
    private Insightly_Organization_Object_Details insightly;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("insightly")
    public Insightly_Organization_Object_Details getInsightly() {
        return insightly;
    }

    @JsonProperty("insightly")
    public void setInsightly(Insightly_Organization_Object_Details insightly) {
        this.insightly = insightly;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
