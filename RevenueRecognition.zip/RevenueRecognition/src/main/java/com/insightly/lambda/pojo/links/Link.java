package com.insightly.lambda.pojo.links;

import com.fasterxml.jackson.annotation.*;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "DETAILS",
        "LINK_ID",
        "LINK_OBJECT_ID",
        "LINK_OBJECT_NAME",
        "OBJECT_ID",
        "OBJECT_NAME",
        "ROLE"
})
public class Link {

    @JsonProperty("DETAILS")
    private Object dETAILS;
    @JsonProperty("LINK_ID")
    private Integer lINKID;
    @JsonProperty("LINK_OBJECT_ID")
    private Integer lINKOBJECTID;
    @JsonProperty("LINK_OBJECT_NAME")
    private String lINKOBJECTNAME;
    @JsonProperty("OBJECT_ID")
    private Integer oBJECTID;
    @JsonProperty("OBJECT_NAME")
    private String oBJECTNAME;
    @JsonProperty("ROLE")
    private Object rOLE;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("DETAILS")
    public Object getDETAILS() {
        return dETAILS;
    }

    @JsonProperty("DETAILS")
    public void setDETAILS(Object dETAILS) {
        this.dETAILS = dETAILS;
    }

    @JsonProperty("LINK_ID")
    public Integer getLINKID() {
        return lINKID;
    }

    @JsonProperty("LINK_ID")
    public void setLINKID(Integer lINKID) {
        this.lINKID = lINKID;
    }

    @JsonProperty("LINK_OBJECT_ID")
    public Integer getLINKOBJECTID() {
        return lINKOBJECTID;
    }

    @JsonProperty("LINK_OBJECT_ID")
    public void setLINKOBJECTID(Integer lINKOBJECTID) {
        this.lINKOBJECTID = lINKOBJECTID;
    }

    @JsonProperty("LINK_OBJECT_NAME")
    public String getLINKOBJECTNAME() {
        return lINKOBJECTNAME;
    }

    @JsonProperty("LINK_OBJECT_NAME")
    public void setLINKOBJECTNAME(String lINKOBJECTNAME) {
        this.lINKOBJECTNAME = lINKOBJECTNAME;
    }

    @JsonProperty("OBJECT_ID")
    public Integer getOBJECTID() {
        return oBJECTID;
    }

    @JsonProperty("OBJECT_ID")
    public void setOBJECTID(Integer oBJECTID) {
        this.oBJECTID = oBJECTID;
    }

    @JsonProperty("OBJECT_NAME")
    public String getOBJECTNAME() {
        return oBJECTNAME;
    }

    @JsonProperty("OBJECT_NAME")
    public void setOBJECTNAME(String oBJECTNAME) {
        this.oBJECTNAME = oBJECTNAME;
    }

    @JsonProperty("ROLE")
    public Object getROLE() {
        return rOLE;
    }

    @JsonProperty("ROLE")
    public void setROLE(Object rOLE) {
        this.rOLE = rOLE;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}