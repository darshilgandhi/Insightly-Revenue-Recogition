package com.insightly.lambda.services;

import com.insightly.lambda.utils.Headers;
import com.insightly.lambda.utils.Responses.ObjectNodeResponse;
import okhttp3.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.net.URL;
import java.util.concurrent.ThreadLocalRandom;

public class RESTCalls {

    private static final Logger logger = LogManager.getLogger(RESTCalls.class);
    private Headers headers = new Headers();
    //OkHttpClient JSON header
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

    public RESTCalls() { }

    //GetMethod - Fetch Record
    public ObjectNodeResponse searchMethod(String recordType, String fieldName, String fieldValue) {

        //Insightly BaseURL
        HttpUrl.Builder baseUrl = new HttpUrl.Builder()
                .scheme("https")
                .host("api.insightly.com")
                .addPathSegment("v3.1")
                .addPathSegment(recordType)
                .addPathSegment("Search")
                .addQueryParameter("field_name", fieldName)
                .addQueryParameter("field_value", fieldValue)
                .addQueryParameter("count_total", "true");

        URL url = baseUrl.build().url();

        okhttp3.Headers okHttpHeaders = okhttp3.Headers.of(headers.headers_Insightly());

        Request request = new Request.Builder()
                .url(url)
                .get()
                .headers(okHttpHeaders)
                .build();

        return processRequest(request);
    }

    //GetMethod - Fetch Record
    public ObjectNodeResponse getMethod(Long recordId, String recordType) {

        //Insightly BaseURL
        HttpUrl.Builder baseUrl = new HttpUrl.Builder()
            .scheme("https")
                .host("api.insightly.com")
                .addPathSegment("v3.1")
                .addPathSegment(recordType)
                .addPathSegment(String.valueOf(recordId))
            .addQueryParameter("count_total", "true");

        URL url = baseUrl.build().url();

        okhttp3.Headers okHttpHeaders = okhttp3.Headers.of(headers.headers_Insightly());

        Request request = new Request.Builder()
                .url(url)
                .get()
                .headers(okHttpHeaders)
                .build();

        return processRequest(request);
    }

    //PostMethod - Record Update
    public ObjectNodeResponse updateMethod(String recordType, String updateType, String body) {
        logger.debug("Update body: " + body);
        //Insightly BaseURL
        HttpUrl.Builder baseUrl = new HttpUrl.Builder()
                .scheme("https")
                .host("api.insightly.com")
                .addPathSegment("v3.1")
                .addPathSegment(recordType);

        URL url = baseUrl.build().url();

        okhttp3.Headers okHttpHeaders = okhttp3.Headers.of(headers.headers_Insightly());

        RequestBody responseBody = RequestBody.create(JSON, body);

        Request request = null;
        if (updateType.equalsIgnoreCase("POST")) {
            request = new Request.Builder()
                    .url(url)
                    .post(responseBody)
                    .headers(okHttpHeaders)
                    .build();
        } else if (updateType.equalsIgnoreCase("PUT")) {
            request = new Request.Builder()
                    .url(url)
                    .put(responseBody)
                    .headers(okHttpHeaders)
                    .build();
        }

        return processRequest(request);
    }

    private ObjectNodeResponse processRequest(Request request) {
        OkHttpClient httpClient = new OkHttpClient.Builder()
                .addInterceptor(new RetryInterceptor())
                .build();

        try {
            Response response = httpClient.newCall(request).execute();

            String result = "failure";
            if (response.isSuccessful()) {
                result = "success";
            }
            String body = response.body().string();
            int statusCode = response.code();
            response.close();
            return new ObjectNodeResponse(result, statusCode, body);
        } catch (IOException e) {
            return new ObjectNodeResponse("failure", -1, e.getMessage());
        }
    }

    private class RetryInterceptor implements Interceptor {
        @Override
        public Response intercept(Chain chain) throws IOException {
            Request request = chain.request();

            // try the request
            Response response = chain.proceed(request);

            int retryCount = 0;
            while (response.code() == 429) {
                logger.info("State code 429. Retrying request. Attempt no. " + retryCount);
                retryCount++;

                int randomNum = ThreadLocalRandom.current().nextInt(800, 1200);
                try {
                    Thread.sleep(randomNum);
                } catch (InterruptedException e2) {
                    logger.error("Thread interruption error... " + e2.getMessage());
                }

                response = chain.proceed(request);
            }

            return response;
        }
    }

}
