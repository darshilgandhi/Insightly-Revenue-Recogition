# Java AWS Lambda - MRR/ARR Implementation

Boilerplate java code using RequestStreamHandler

## Getting Started

Clone or download, compile and upload the jar file in AWS Lambda. 

```
mvn clean package -DskipTests
```

### Prerequisites

Java JDK 1.8 & Maven 3.5.0. 

## Version

1.0.0

## Authors

* **Ron Shah** - *Initial work*

## License

Insightly Inc Terms and Conditions.